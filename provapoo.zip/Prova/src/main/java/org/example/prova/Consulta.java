package org.example.prova;

import java.util.Objects;

public class Consulta {
    private Integer id;
    private String dataConsulta;
    private String descricaoExame;
    private String historico;

    public Consulta() {
    }

    public Consulta(Integer id, String dataConsulta, String descricaoExame, String historico) {
        this.id = id;
        this.dataConsulta = String.valueOf(dataConsulta);
        this.descricaoExame = descricaoExame;
        this.historico = historico;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getDataConsulta() {
        return dataConsulta;
    }

    public void setDataConsulta(String dataConsulta) {
        this.dataConsulta = String.valueOf(dataConsulta);
    }

    public String getDescricaoExame() {
        return descricaoExame;
    }

    public void setDescricaoExame(String descricaoExame) {
        this.descricaoExame = descricaoExame;
    }

    public String getHistorico() {
        return historico;
    }

    public void setHistorico(String historico) {
        this.historico = historico;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Consulta consulta = (Consulta) o;
        return Objects.equals(id, consulta.id) && Objects.equals(dataConsulta, consulta.dataConsulta) && Objects.equals(descricaoExame, consulta.descricaoExame) && Objects.equals(historico, consulta.historico);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, dataConsulta, descricaoExame, historico);
    }

    @Override
    public String toString() {
        return "Consulta{" +
                "id=" + id +
                ", dataConsulta=" + dataConsulta +
                ", descricaoExame='" + descricaoExame + '\'' +
                ", historico='" + historico + '\'' +
                '}';
    }
}
