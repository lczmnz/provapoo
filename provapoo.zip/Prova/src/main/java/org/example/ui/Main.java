package org.example.ui;
import org.example.prova.Consulta;
import org.example.prova.Veterinario;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        var v = new Veterinario();
        var c = new Consulta();

        c.setId(1);
        c.setDataConsulta ("06/10/2023");
        c.setHistorico("Animal quebrou a pata");
        c.setDescricaoExame("Engessar a pata");

        v.setId(1);
        v.setEndereco("Av. João César de Oliveira, 1000, Eldorado, Contagem - MG");
        v.setNome("Meg");
        v.setTelefone("(31)90001-3222");






    }
}
